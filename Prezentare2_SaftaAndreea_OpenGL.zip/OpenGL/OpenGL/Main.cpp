﻿#include <windows.h>
#include <glew.h>
#include <freeglut.h>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include <iostream>
#include <cmath>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif


const int WIDTH = 800;
const int HEIGHT = 800;


float cameraX = 0.0f, cameraY = 0.0f, cameraZ = 3.0f;
float yaw = -90.0f, pitch = 0.0f;
float cameraSpeed = 0.1f;
bool mouseLeftPressed = false;
float sensitivity = 0.2f;
int lastMouseX, lastMouseY;

GLuint textureFloor, textureWall, textureWallS, textureCeiling, textureGlass, textureDoor, textureSphere,
textureSphere2, textureSphere3, textureCub, textureBear, textureEye, textureInnerEar, textureNose, textureBearInner, textureCarpet;



void loadTexture(const char* filename, GLuint& textureID) {
    int width, height, nrChannels;

    
    stbi_set_flip_vertically_on_load(true);

    unsigned char* data = stbi_load(filename, &width, &height, &nrChannels, 0);
    if (data) {
        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

      
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

        GLenum format = (nrChannels == 4) ? GL_RGBA : GL_RGB;
        glTexImage2D(GL_TEXTURE_2D, 0, format == GL_RGBA ? GL_RGBA8 : GL_RGB8, width, height, 0, format, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(data);
        std::cout << "Textura a fost incarcata cu succes: " << width << "x" << height << std::endl;
    }
    else {
        std::cerr << "Eroare la incarcarea texturii: " << filename << std::endl;
    }
}

void drawSkybox() {
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_FRONT);

    // podeaua
    glBindTexture(GL_TEXTURE_2D, textureFloor);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(-5, -5, -5);
    glTexCoord2f(1, 0); glVertex3f(5, -5, -5);
    glTexCoord2f(1, 1); glVertex3f(5, -5, 5);
    glTexCoord2f(0, 1); glVertex3f(-5, -5, 5);
    glEnd();

    //covor
    glBindTexture(GL_TEXTURE_2D, textureCarpet);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(-4.5, -4.9, -3.5);
    glTexCoord2f(1, 0); glVertex3f(4.5, -4.9, -3.5);
    glTexCoord2f(1, 1); glVertex3f(4.5, -4.9, 3.5);
    glTexCoord2f(0, 1); glVertex3f(-4.5, -4.9, 3.5);
    glEnd();

    // peretele cu peisaj
    glBindTexture(GL_TEXTURE_2D, textureWall);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(5, -5, -5);
    glTexCoord2f(1, 0); glVertex3f(-5, -5, -5);
    glTexCoord2f(1, 1); glVertex3f(-5, 5, -5);
    glTexCoord2f(0, 1); glVertex3f(5, 5, -5);
    glEnd();

    // Geamul transparent
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBindTexture(GL_TEXTURE_2D, textureGlass);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(5, -5, -5);
    glTexCoord2f(1, 0); glVertex3f(-5, -5, -5);
    glTexCoord2f(1, 1); glVertex3f(-5, 5, -4.9);
    glTexCoord2f(0, 1); glVertex3f(5, 5, -4.9);
    glEnd();
    glDisable(GL_BLEND);

    // peretele din spate
    glBindTexture(GL_TEXTURE_2D, textureWallS);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(-5, -5, 5);
    glTexCoord2f(1, 0); glVertex3f(5, -5, 5);
    glTexCoord2f(1, 1); glVertex3f(5, 5, 5);
    glTexCoord2f(0, 1); glVertex3f(-5, 5, 5);
    glEnd();

    // peretele stanga
    glBindTexture(GL_TEXTURE_2D, textureWallS);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(-5, -5, -5);
    glTexCoord2f(1, 0); glVertex3f(-5, -5, 5);
    glTexCoord2f(1, 1); glVertex3f(-5, 5, 5);
    glTexCoord2f(0, 1); glVertex3f(-5, 5, -5);
    glEnd();

    // peretele dreapta
   
    glBindTexture(GL_TEXTURE_2D, textureWallS);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 1); glVertex3f(5, -5, -5);
    glTexCoord2f(0, 0); glVertex3f(5, 5, -5);
    glTexCoord2f(1, 0); glVertex3f(5, 5, 5);
    glTexCoord2f(1, 1); glVertex3f(5, -5, 5);
    glEnd();

    //Usa
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBindTexture(GL_TEXTURE_2D, textureDoor);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(4.9, -5, 1);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(4.9, -5, -2);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(4.9, 1, -2);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(4.9, 1, 1);
    glEnd();
    glDisable(GL_BLEND);

    // tavan
    glBindTexture(GL_TEXTURE_2D, textureCeiling);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(-5, 5, 5);
    glTexCoord2f(1, 0); glVertex3f(5, 5, 5);
    glTexCoord2f(1, 1); glVertex3f(5, 5, -5);
    glTexCoord2f(0, 1); glVertex3f(-5, 5, -5);
    glEnd();

    glDisable(GL_TEXTURE_2D);

 
}

void drawTexturedSphere(float x, float y, float z, float radius, GLuint texture) {
    GLUquadric* quad = gluNewQuadric();
    glBindTexture(GL_TEXTURE_2D, texture);

    glEnable(GL_TEXTURE_2D);
    gluQuadricTexture(quad, GL_TRUE);

    glPushMatrix();
    glTranslatef(x, y, z);
    gluSphere(quad, radius, 30, 30);
    glPopMatrix();

    glDisable(GL_TEXTURE_2D);
    gluDeleteQuadric(quad);
}

void drawTexturedCube(float x, float y, float z, float size, GLuint texture, bool isSmallCube) {
    if (isSmallCube) {
        
        glEnable(GL_CULL_FACE);
        glCullFace(GL_BACK);  
    }
    else {
        glDisable(GL_CULL_FACE);  
    }

    glBindTexture(GL_TEXTURE_2D, texture);

    glEnable(GL_TEXTURE_2D);

    

   
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(x - size / 2, y - size / 2, z + size / 2);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(x + size / 2, y - size / 2, z + size / 2);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(x + size / 2, y + size / 2, z + size / 2);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(x - size / 2, y + size / 2, z + size / 2);
    glEnd();

   
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(x - size / 2, y - size / 2, z - size / 2);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(x - size / 2, y + size / 2, z - size / 2);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(x + size / 2, y + size / 2, z - size / 2);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(x + size / 2, y - size / 2, z - size / 2);
    glEnd();

   
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(x - size / 2, y - size / 2, z - size / 2);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(x - size / 2, y - size / 2, z + size / 2);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(x - size / 2, y + size / 2, z + size / 2);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(x - size / 2, y + size / 2, z - size / 2);
    glEnd();

   
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(x + size / 2, y - size / 2, z - size / 2);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(x + size / 2, y + size / 2, z - size / 2);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(x + size / 2, y + size / 2, z + size / 2);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(x + size / 2, y - size / 2, z + size / 2);
    glEnd();

   
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(x - size / 2, y - size / 2, z - size / 2);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(x + size / 2, y - size / 2, z - size / 2);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(x + size / 2, y - size / 2, z + size / 2);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(x - size / 2, y - size / 2, z + size / 2);
    glEnd();

  
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(x - size / 2, y + size / 2, z - size / 2);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(x - size / 2, y + size / 2, z + size / 2);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(x + size / 2, y + size / 2, z + size / 2);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(x + size / 2, y + size / 2, z - size / 2);
    glEnd();

    glDisable(GL_TEXTURE_2D);

    if (isSmallCube) {
        glDisable(GL_CULL_FACE); 
    }
}

void drawTeddyBear(float x, float y, float z) {
    // Corpul ursului
    drawTexturedSphere(x, y, z, 1.0f, textureBear);

    float bellyButtonRadius = 0.7f;
    drawTexturedSphere(x, y , z + 0.4f, bellyButtonRadius, textureBearInner);
    

    // Capul ursului
    drawTexturedSphere(x, y + 1.5f, z, 0.8f, textureBear);

    // Urechile ursului
    drawTexturedSphere(x - 0.7f, y + 2.2f, z, 0.3f, textureBear);
    drawTexturedSphere(x + 0.7f, y + 2.2f, z, 0.3f, textureBear);

    // sfere mai mici in urechile ursului
    float innerEarRadius = 0.15f;  
    drawTexturedSphere(x - 0.7f, y + 2.25f, z + 0.2f, innerEarRadius, textureInnerEar);  
    drawTexturedSphere(x + 0.7f, y + 2.25f, z + 0.2f, innerEarRadius, textureInnerEar);  

    drawTexturedSphere(x - 0.7f, y + 2.15f, z - 0.1f, innerEarRadius, textureInnerEar);  
    drawTexturedSphere(x + 0.7f, y + 2.15f, z - 0.1f, innerEarRadius, textureInnerEar);  

    // picioare
    drawTexturedSphere(x - 0.5f, y - 0.5f, z, 0.5f, textureBear);
    drawTexturedSphere(x + 0.5f, y - 0.5f, z, 0.5f, textureBear);

    // maini
    drawTexturedSphere(x - 1.0f, y + 0.5f, z, 0.3f, textureBear);
    drawTexturedSphere(x + 1.0f, y + 0.5f, z, 0.3f, textureBear);

    //ochii
    float eyeRadius = 0.10f; 
    float eyeOffsetX = 0.25f;
    float eyeOffsetY = 0.3f;  

    // Ochii
    drawTexturedSphere(x - eyeOffsetX, y + 1.8f, z + 0.6f, eyeRadius, textureEye); 
    drawTexturedSphere(x + eyeOffsetX, y + 1.8f, z + 0.6f, eyeRadius, textureEye); 

    // nas
    float noseRadius = 0.10f;  
    drawTexturedSphere(x, y + 1.5f, z + 0.8f, noseRadius, textureNose); 
}


void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    float dirX = cos(yaw * M_PI / 180.0) * cos(pitch * M_PI / 180.0);
    float dirY = sin(pitch * M_PI / 180.0);
    float dirZ = sin(yaw * M_PI / 180.0) * cos(pitch * M_PI / 180.0);

    gluLookAt(cameraX, cameraY, cameraZ,
        cameraX + dirX, cameraY + dirY, cameraZ + dirZ,
        0, 1, 0);
                      //x            y     dim
    drawTexturedSphere(4.5f, -4.6f, -3.5f, 0.3f,textureSphere);
    drawTexturedSphere(1.0f, -4.7f, -4.5f, 0.3f,textureSphere2);
    drawTexturedSphere(3.5f, -4.6f, -3.0f, 0.3f,textureSphere3);

    drawTexturedCube(4.0f, -4.7f, -4.3f, 0.8f, textureCub, false);

    drawTeddyBear(-3.0f, -4.0f, -3.0f);

    drawSkybox();
    glutSwapBuffers();
}


void moveCamera(int key, int x, int y) {
    float dirX = cos(yaw * M_PI / 180.0);
    float dirZ = sin(yaw * M_PI / 180.0);

    switch (key) {
    case GLUT_KEY_UP:    cameraX += dirX * cameraSpeed; cameraZ += dirZ * cameraSpeed; break;
    case GLUT_KEY_DOWN:  cameraX -= dirX * cameraSpeed; cameraZ -= dirZ * cameraSpeed; break;
    case GLUT_KEY_LEFT:  cameraX -= dirZ * cameraSpeed; cameraZ += dirX * cameraSpeed; break;
    case GLUT_KEY_RIGHT: cameraX += dirZ * cameraSpeed; cameraZ -= dirX * cameraSpeed; break;
    }
    glutPostRedisplay();
}


void mouseButton(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON) {
        mouseLeftPressed = (state == GLUT_DOWN);
        lastMouseX = x;
        lastMouseY = y;
    }
}


void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0, (float)w / h, 0.1, 100.0);
    glMatrixMode(GL_MODELVIEW);
}


void mouseMotion(int x, int y) {
    if (!mouseLeftPressed) return;

    float offsetX = (x - lastMouseX) * sensitivity;
    float offsetY = (lastMouseY - y) * sensitivity; 

    lastMouseX = x;
    lastMouseY = y;

    yaw += offsetX;
    pitch += offsetY;

    if (pitch > 89.0f) pitch = 89.0f;
    if (pitch < -89.0f) pitch = -89.0f;

    glutPostRedisplay();
}



int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(WIDTH, HEIGHT);
    glutCreateWindow("Camera Free Look with Texture");

    //initializare GLEW
    glewInit();
    if (!glewIsSupported("GL_VERSION_2_0")) {
        std::cerr << "OpenGL 2.0 nu este suportat!" << std::endl;
        return -1;
    }

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_FRONT);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/wood2.jpg", textureFloor);
    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/spring1.jpg", textureWall);
    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/wall.jpg", textureWallS);
    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/ceiling.jpg", textureCeiling);
    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/door1.png", textureGlass);
    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/door3.jpg", textureDoor);
    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/fabric.jpg", textureSphere);
    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/red.jpg", textureSphere2);
    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/wool.jpg", textureSphere3);
    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/tile.jpg", textureCub);
    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/fur.jpg", textureBear);
    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/eye.jpg", textureEye);
    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/eye.jpg", textureNose);
    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/pink.jpg", textureInnerEar);
    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/pink.jpg", textureBearInner);
    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/carpet.jpg", textureCarpet);




    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutSpecialFunc(moveCamera);
    glutMouseFunc(mouseButton);
    glutMotionFunc(mouseMotion);

    glutMainLoop();
    return 0;
}


