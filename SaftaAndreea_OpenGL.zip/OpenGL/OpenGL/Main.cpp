﻿#include <windows.h>
#include <glew.h>
#include <freeglut.h>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include <iostream>
#include <cmath>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif


const int WIDTH = 800;
const int HEIGHT = 800;


float cameraX = 0.0f, cameraY = 0.0f, cameraZ = 3.0f;
float yaw = -90.0f, pitch = 0.0f;
float cameraSpeed = 0.1f;
bool mouseLeftPressed = false;
float sensitivity = 0.2f;
int lastMouseX, lastMouseY;

GLuint textureFloor, textureWall, textureWallS, textureCeiling, textureGlass;



void loadTexture(const char* filename, GLuint& textureID) {
    int width, height, nrChannels;

    
    stbi_set_flip_vertically_on_load(true);

    unsigned char* data = stbi_load(filename, &width, &height, &nrChannels, 0);
    if (data) {
        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

      
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        GLenum format = (nrChannels == 4) ? GL_RGBA : GL_RGB;
        glTexImage2D(GL_TEXTURE_2D, 0, format == GL_RGBA ? GL_RGBA8 : GL_RGB8, width, height, 0, format, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(data);
        std::cout << "Textura a fost incarcata cu succes: " << width << "x" << height << std::endl;
    }
    else {
        std::cerr << "Eroare la incarcarea texturii: " << filename << std::endl;
    }
}

void drawSkybox() {
    glEnable(GL_TEXTURE_2D);

    // podeaua
    glBindTexture(GL_TEXTURE_2D, textureFloor);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(-5, -5, -5);
    glTexCoord2f(1, 0); glVertex3f(5, -5, -5);
    glTexCoord2f(1, 1); glVertex3f(5, -5, 5);
    glTexCoord2f(0, 1); glVertex3f(-5, -5, 5);
    glEnd();

    // peretele cu peisaj
    glBindTexture(GL_TEXTURE_2D, textureWall);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(5, -5, -5);
    glTexCoord2f(1, 0); glVertex3f(-5, -5, -5);
    glTexCoord2f(1, 1); glVertex3f(-5, 5, -5);
    glTexCoord2f(0, 1); glVertex3f(5, 5, -5);
    glEnd();

    // Geamul transparent
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBindTexture(GL_TEXTURE_2D, textureGlass);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(5, -5, -5);
    glTexCoord2f(1, 0); glVertex3f(-5, -5, -5);
    glTexCoord2f(1, 1); glVertex3f(-5, 5, -4.9);
    glTexCoord2f(0, 1); glVertex3f(5, 5, -4.9);
    glEnd();
    glDisable(GL_BLEND);

    // peretele din spate
    glBindTexture(GL_TEXTURE_2D, textureWallS);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(-5, -5, 5);
    glTexCoord2f(1, 0); glVertex3f(5, -5, 5);
    glTexCoord2f(1, 1); glVertex3f(5, 5, 5);
    glTexCoord2f(0, 1); glVertex3f(-5, 5, 5);
    glEnd();

    // peretele stanga
    glBindTexture(GL_TEXTURE_2D, textureWallS);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(-5, -5, -5);
    glTexCoord2f(1, 0); glVertex3f(-5, -5, 5);
    glTexCoord2f(1, 1); glVertex3f(-5, 5, 5);
    glTexCoord2f(0, 1); glVertex3f(-5, 5, -5);
    glEnd();

    // peretele dreapta
    glBindTexture(GL_TEXTURE_2D, textureWallS);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 1); glVertex3f(5, -5, -5);
    glTexCoord2f(0, 0); glVertex3f(5, 5, -5);
    glTexCoord2f(1, 0); glVertex3f(5, 5, 5);
    glTexCoord2f(1, 1); glVertex3f(5, -5, 5);
    glEnd();

    // tavan
    glBindTexture(GL_TEXTURE_2D, textureCeiling);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(-5, 5, 5);
    glTexCoord2f(1, 0); glVertex3f(5, 5, 5);
    glTexCoord2f(1, 1); glVertex3f(5, 5, -5);
    glTexCoord2f(0, 1); glVertex3f(-5, 5, -5);
    glEnd();

    glDisable(GL_TEXTURE_2D);
}


void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    float dirX = cos(yaw * M_PI / 180.0) * cos(pitch * M_PI / 180.0);
    float dirY = sin(pitch * M_PI / 180.0);
    float dirZ = sin(yaw * M_PI / 180.0) * cos(pitch * M_PI / 180.0);

    gluLookAt(cameraX, cameraY, cameraZ,
        cameraX + dirX, cameraY + dirY, cameraZ + dirZ,
        0, 1, 0);

    drawSkybox();
    glutSwapBuffers();
}


void moveCamera(int key, int x, int y) {
    float dirX = cos(yaw * M_PI / 180.0);
    float dirZ = sin(yaw * M_PI / 180.0);

    switch (key) {
    case GLUT_KEY_UP:    cameraX += dirX * cameraSpeed; cameraZ += dirZ * cameraSpeed; break;
    case GLUT_KEY_DOWN:  cameraX -= dirX * cameraSpeed; cameraZ -= dirZ * cameraSpeed; break;
    case GLUT_KEY_LEFT:  cameraX -= dirZ * cameraSpeed; cameraZ += dirX * cameraSpeed; break;
    case GLUT_KEY_RIGHT: cameraX += dirZ * cameraSpeed; cameraZ -= dirX * cameraSpeed; break;
    }
    glutPostRedisplay();
}


void mouseButton(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON) {
        mouseLeftPressed = (state == GLUT_DOWN);
        lastMouseX = x;
        lastMouseY = y;
    }
}


void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0, (float)w / h, 0.1, 100.0);
    glMatrixMode(GL_MODELVIEW);
}


void mouseMotion(int x, int y) {
    if (!mouseLeftPressed) return;

    float offsetX = (x - lastMouseX) * sensitivity;
    float offsetY = (lastMouseY - y) * sensitivity; 

    lastMouseX = x;
    lastMouseY = y;

    yaw += offsetX;
    pitch += offsetY;

    if (pitch > 89.0f) pitch = 89.0f;
    if (pitch < -89.0f) pitch = -89.0f;

    glutPostRedisplay();
}



int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(WIDTH, HEIGHT);
    glutCreateWindow("Camera Free Look with Texture");

    //initializare GLEW
    glewInit();
    if (!glewIsSupported("GL_VERSION_2_0")) {
        std::cerr << "OpenGL 2.0 nu este suportat!" << std::endl;
        return -1;
    }

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_FRONT);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/wood2.jpg", textureFloor);
    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/spring1.jpg", textureWall);
    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/wall.jpg", textureWallS);
    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/ceiling.jpg", textureCeiling);
    loadTexture("C:/Users/Andreea/Desktop/AN4/sem2/SPG/images/door1.png", textureGlass);



    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutSpecialFunc(moveCamera);
    glutMouseFunc(mouseButton);
    glutMotionFunc(mouseMotion);

    glutMainLoop();
    return 0;
}


